#!/usr/bin/gnuplot -persist


#######################################################################################
#######################################  PLOT  1  #####################################

set terminal pdfcairo enhanced
#set terminal wxt size 350,262 enhanced font 'Verdana,10' persist

set output "Mpotf_L55_m15_magrot.pdf"
#set output "Mpotf_L88_m15.txt"


set autoscale
set xlabel "r [km]"
set ylabel "M(r)"
set label "Mag. field + rotation" at 2,-0.02 
set label "(L=55)" at 2,-0.022 




set style line 1 lt 1

set style rect fc lt -1 fs transparent solid 0.5 noborder


#set obj rect from 9.96780982962 , graph 0 to 9.71320523766 , graph 1 fc rgb "black" fs transparent pattern 4
#set obj rect from 10.080714138 , graph 0 to 9.82997150597 , graph 1 fc rgb "brown" fs transparent pattern 5
#set obj rect from 10.190900276 , graph 0 to 9.95008174255 , graph 1 fc rgb "red" fs transparent pattern 6
#set obj rect from 10.2485103746 , graph 0 to 10.0071218952 , graph 1 fc rgb "green" fs transparent pattern 7

##set obj rect from 9.96780982962 , graph 0 to 9.71320523766 , graph 1 fc rgb "black" fs transparent pattern 4
##set obj rect from 10.080714138 , graph 0 to 9.82997150597 , graph 1 fc rgb "green" fs transparent pattern 5
##set obj rect from 10.190900276 , graph 0 to 9.95008174255 , graph 1 fc rgb "yellow" fs transparent pattern 6
##set obj rect from 10.2485103746 , graph 0 to 10.0071218952 , graph 1 fc rgb "red" fs transparent pattern 7

set multiplot
# === Large plot ===
unset key
plot "Magpot_angles_L55_magrot15.d" using 1:2 with lines ls 1 lw 3 lc rgb "#e3f2fd" title "π/8" at end ,\
"Magpot_angles_L55_magrot15.d" using 1:3 with lines ls 1 lw 3 lc rgb "#90caf9"   title "π/4" at end,\
"Magpot_angles_L55_magrot15.d" using 1:4 with lines ls 1 lw 3 lc rgb "#1976d2"  title "3π/8" at end,\
"Magpot_angles_L55_magrot15.d" using 1:5 with lines ls 1 lw 3 lc rgb "#0d47a1"   title "π/2" at end,\

# === Small plot ===
set origin 8.,0.0
set size 3,3
set xrange [8:10]
set yrange [-0.0035:0]
unset xlabel
unset ylabel
unset label



plot "Magpot_angles_L55_magrot15.d" using 1:2 with lines ls 1 lw 3 lc rgb "purple",\
"Magpot_angles_L55_magrot15.d" using 1:3 with lines ls 1 lw 3 lc rgb "brown" ,\
"Magpot_angles_L55_magrot15.d" using 1:4 with lines ls 1 lw 3 lc rgb "cyan" ,\
"Magpot_angles_L55_magrot15.d" using 1:5 with lines ls 1 lw 3 lc rgb "grey" 

unset multiplot

#######################################################################################
#######################################  PLOT  2  #####################################
reset

set terminal pdfcairo enhanced
#set terminal wxt size 350,262 enhanced font 'Verdana,10' persist

set output "Mpotf_L55_m15_mag.pdf"
#set output "Mpotf_L88_m15.txt"


set autoscale
set xlabel "r [km]"
set ylabel "M(r)"
set label "Mag. field only" at 1.5,-0.001 
set label "(L=55)" at 1.5,-0.0012 

set yrange [-0.0016:0]




set style line 1 lt 1

set style rect fc lt -1 fs transparent solid 0.5 noborder


#set obj rect from 9.96780982962 , graph 0 to 9.71320523766 , graph 1 fc rgb "black" fs transparent pattern 4
#set obj rect from 10.080714138 , graph 0 to 9.82997150597 , graph 1 fc rgb "brown" fs transparent pattern 5
#set obj rect from 10.190900276 , graph 0 to 9.95008174255 , graph 1 fc rgb "red" fs transparent pattern 6
#set obj rect from 10.2485103746 , graph 0 to 10.0071218952 , graph 1 fc rgb "green" fs transparent pattern 7

##set obj rect from 9.96780982962 , graph 0 to 9.71320523766 , graph 1 fc rgb "black" fs transparent pattern 4
##set obj rect from 10.080714138 , graph 0 to 9.82997150597 , graph 1 fc rgb "green" fs transparent pattern 5
##set obj rect from 10.190900276 , graph 0 to 9.95008174255 , graph 1 fc rgb "yellow" fs transparent pattern 6
##set obj rect from 10.2485103746 , graph 0 to 10.0071218952 , graph 1 fc rgb "red" fs transparent pattern 7

set multiplot
# === Large plot ===
unset key
plot "Magpot_angles_L55_mag.d" using 1:2 with lines ls 1 lw 3 lc rgb "#e3f2fd" title "π/8" at end ,\
"Magpot_angles_L55_mag.d" using 1:3 with lines ls 1 lw 3 lc rgb "#90caf9"   title "π/4" at end,\
"Magpot_angles_L55_mag.d" using 1:4 with lines ls 1 lw 3 lc rgb "#1976d2"  title "3π/8" at end,\
"Magpot_angles_L55_mag.d" using 1:5 with lines ls 1 lw 3 lc rgb "#0d47a1"   title "π/2" at end,\

# === Small plot ===
set origin 8.,0.0
set size 3,3
set xrange [8:10]
set yrange [-0.0035:0]
unset xlabel
unset ylabel
unset label


plot "Magpot_angles_L55_mag.d" using 1:2 with lines ls 1 lw 3 lc rgb "purple",\
"Magpot_angles_L55_mag.d" using 1:3 with lines ls 1 lw 3 lc rgb "brown" ,\
"Magpot_angles_L55_mag.d" using 1:4 with lines ls 1 lw 3 lc rgb "cyan" ,\
"Magpot_angles_L55_mag.d" using 1:5 with lines ls 1 lw 3 lc rgb "grey" 

unset multiplot



#######################################################################################
#######################################  PLOT  3  #####################################
reset

set terminal pdfcairo enhanced
#set terminal wxt size 350,262 enhanced font 'Verdana,10' persist

set output "Mpotf_L88_m15_magrot.pdf"
#set output "Mpotf_L88_m15.txt"


set autoscale
set xlabel "r [km]"
set ylabel "M(r)"
set label "Mag. field + rotation" at 1.5,-0.02 
set label "(L=88)" at 1.5,-0.022 





set style line 1 lt 1

set style rect fc lt -1 fs transparent solid 0.5 noborder


#set obj rect from 9.96780982962 , graph 0 to 9.71320523766 , graph 1 fc rgb "black" fs transparent pattern 4
#set obj rect from 10.080714138 , graph 0 to 9.82997150597 , graph 1 fc rgb "brown" fs transparent pattern 5
#set obj rect from 10.190900276 , graph 0 to 9.95008174255 , graph 1 fc rgb "red" fs transparent pattern 6
#set obj rect from 10.2485103746 , graph 0 to 10.0071218952 , graph 1 fc rgb "green" fs transparent pattern 7

##set obj rect from 9.96780982962 , graph 0 to 9.71320523766 , graph 1 fc rgb "black" fs transparent pattern 4
##set obj rect from 10.080714138 , graph 0 to 9.82997150597 , graph 1 fc rgb "green" fs transparent pattern 5
##set obj rect from 10.190900276 , graph 0 to 9.95008174255 , graph 1 fc rgb "yellow" fs transparent pattern 6
##set obj rect from 10.2485103746 , graph 0 to 10.0071218952 , graph 1 fc rgb "red" fs transparent pattern 7

set multiplot
# === Large plot ===
unset key
plot "Magpot_angles_L88_magrot.d" using 1:2 with lines ls 1 lw 3 lc rgb "#e3f2fd" title "π/8" at end ,\
"Magpot_angles_L88_magrot.d" using 1:3 with lines ls 1 lw 3 lc rgb "#90caf9"   title "π/4" at end,\
"Magpot_angles_L88_magrot.d" using 1:4 with lines ls 1 lw 3 lc rgb "#1976d2"  title "3π/8" at end,\
"Magpot_angles_L88_magrot.d" using 1:5 with lines ls 1 lw 3 lc rgb "#0d47a1"   title "π/2" at end,\

# === Small plot ===
set origin 8.,0.0
set size 3,3
set xrange [8:10]
set yrange [-0.0035:0]
unset xlabel
unset ylabel
unset label




plot "Magpot_angles_L88_magrot.d" using 1:2 with lines ls 1 lw 3 lc rgb "purple",\
"Magpot_angles_L88_magrot.d" using 1:3 with lines ls 1 lw 3 lc rgb "brown" ,\
"Magpot_angles_L88_magrot.d" using 1:4 with lines ls 1 lw 3 lc rgb "cyan" ,\
"Magpot_angles_L88_magrot.d" using 1:5 with lines ls 1 lw 3 lc rgb "grey" 

unset multiplot

#######################################################################################
#######################################  PLOT  4  #####################################
reset

set terminal pdfcairo enhanced
#set terminal wxt size 350,262 enhanced font 'Verdana,10' persist

set output "Mpotf_L88_m15_mag.pdf"
#set output "Mpotf_L88_m15.txt"


set autoscale
set xlabel "r [km]"
set ylabel "M(r)"
set label "Mag. field only" at 1.5,-0.001 
set label "(L=88)" at 1.5,-0.0012 
set yrange [-0.0016:0]





set style line 1 lt 1

set style rect fc lt -1 fs transparent solid 0.5 noborder


#set obj rect from 9.96780982962 , graph 0 to 9.71320523766 , graph 1 fc rgb "black" fs transparent pattern 4
#set obj rect from 10.080714138 , graph 0 to 9.82997150597 , graph 1 fc rgb "brown" fs transparent pattern 5
#set obj rect from 10.190900276 , graph 0 to 9.95008174255 , graph 1 fc rgb "red" fs transparent pattern 6
#set obj rect from 10.2485103746 , graph 0 to 10.0071218952 , graph 1 fc rgb "green" fs transparent pattern 7

##set obj rect from 9.96780982962 , graph 0 to 9.71320523766 , graph 1 fc rgb "black" fs transparent pattern 4
##set obj rect from 10.080714138 , graph 0 to 9.82997150597 , graph 1 fc rgb "green" fs transparent pattern 5
##set obj rect from 10.190900276 , graph 0 to 9.95008174255 , graph 1 fc rgb "yellow" fs transparent pattern 6
##set obj rect from 10.2485103746 , graph 0 to 10.0071218952 , graph 1 fc rgb "red" fs transparent pattern 7

set multiplot
# === Large plot ===
unset key
plot "Magpot_angles_L88_mag.d" using 1:2 with lines ls 1 lw 3 lc rgb "#e3f2fd" title "π/8" at end ,\
"Magpot_angles_L88_mag.d" using 1:3 with lines ls 1 lw 3 lc rgb "#90caf9"   title "π/4" at end,\
"Magpot_angles_L88_mag.d" using 1:4 with lines ls 1 lw 3 lc rgb "#1976d2"  title "3π/8" at end,\
"Magpot_angles_L88_mag.d" using 1:5 with lines ls 1 lw 3 lc rgb "#0d47a1"   title "π/2" at end,\

# === Small plot ===
set origin 8.,0.0
set size 3,3
set xrange [8:10]
set yrange [-0.0035:0]
unset xlabel
unset ylabel
unset label


plot "Magpot_angles_L88_mag.d" using 1:2 with lines ls 1 lw 3 lc rgb "purple",\
"Magpot_angles_L88_mag.d" using 1:3 with lines ls 1 lw 3 lc rgb "brown" ,\
"Magpot_angles_L88_mag.d" using 1:4 with lines ls 1 lw 3 lc rgb "cyan" ,\
"Magpot_angles_L88_mag.d" using 1:5 with lines ls 1 lw 3 lc rgb "grey" 

unset multiplot

#######################################################################################
#######################################  PLOT  5  #####################################
reset

set terminal pdfcairo enhanced
#set terminal wxt size 350,262 enhanced font 'Verdana,10' persist

set output "Mpotf_L55_m15_mag_2.pdf"
#set output "Mpotf_L88_m15.txt"


set autoscale
set xlabel "r [km]"
set ylabel "M(r)"
set label "Mag. field only" at 1.5,-0.0008 
set label "(L=55)" at 1.5,-0.0009 
set yrange [-0.0012:0]




set style line 1 lt 1

set style rect fc lt -1 fs transparent solid 0.5 noborder


#set obj rect from 9.96780982962 , graph 0 to 9.71320523766 , graph 1 fc rgb "black" fs transparent pattern 4
#set obj rect from 10.080714138 , graph 0 to 9.82997150597 , graph 1 fc rgb "brown" fs transparent pattern 5
#set obj rect from 10.190900276 , graph 0 to 9.95008174255 , graph 1 fc rgb "red" fs transparent pattern 6
#set obj rect from 10.2485103746 , graph 0 to 10.0071218952 , graph 1 fc rgb "green" fs transparent pattern 7

##set obj rect from 9.96780982962 , graph 0 to 9.71320523766 , graph 1 fc rgb "black" fs transparent pattern 4
##set obj rect from 10.080714138 , graph 0 to 9.82997150597 , graph 1 fc rgb "green" fs transparent pattern 5
##set obj rect from 10.190900276 , graph 0 to 9.95008174255 , graph 1 fc rgb "yellow" fs transparent pattern 6
##set obj rect from 10.2485103746 , graph 0 to 10.0071218952 , graph 1 fc rgb "red" fs transparent pattern 7

set multiplot
# === Large plot ===
unset key
plot "Magpot_angles_L55_mag15_2.d" using 1:2 with lines ls 1 lw 3 lc rgb "#e3f2fd" title "π/8" at end ,\
"Magpot_angles_L55_mag15_2.d" using 1:3 with lines ls 1 lw 3 lc rgb "#90caf9"   title "π/4" at end,\
"Magpot_angles_L55_mag15_2.d" using 1:4 with lines ls 1 lw 3 lc rgb "#1976d2"  title "3π/8" at end,\
"Magpot_angles_L55_mag15_2.d" using 1:5 with lines ls 1 lw 3 lc rgb "#0d47a1"   title "π/2" at end,\

# === Small plot ===
set origin 8.,0.0
set size 3,3
set xrange [8:10]
set yrange [-0.0035:0]
unset xlabel
unset ylabel
unset label


plot "Magpot_angles_L55_mag15_2.d" using 1:2 with lines ls 1 lw 3 lc rgb "purple",\
"Magpot_angles_L55_mag15_2.d" using 1:3 with lines ls 1 lw 3 lc rgb "brown" ,\
"Magpot_angles_L55_mag15_2.d" using 1:4 with lines ls 1 lw 3 lc rgb "cyan" ,\
"Magpot_angles_L55_mag15_2.d" using 1:5 with lines ls 1 lw 3 lc rgb "grey" 

unset multiplot

#######################################################################################
#######################################  PLOT  6  #####################################
reset

set terminal pdfcairo enhanced
#set terminal wxt size 350,262 enhanced font 'Verdana,10' persist

set output "Mpotf_L88_m15_mag_2.pdf"
#set output "Mpotf_L88_m15.txt"


set autoscale
set xlabel "r [km]"
set ylabel "M(r)"
set label "Mag. field only" at 1.5,-0.0008 
set label "(L=88)" at 1.5,-0.0009 
set yrange [-0.0012:0]





set style line 1 lt 1

set style rect fc lt -1 fs transparent solid 0.5 noborder


#set obj rect from 9.96780982962 , graph 0 to 9.71320523766 , graph 1 fc rgb "black" fs transparent pattern 4
#set obj rect from 10.080714138 , graph 0 to 9.82997150597 , graph 1 fc rgb "brown" fs transparent pattern 5
#set obj rect from 10.190900276 , graph 0 to 9.95008174255 , graph 1 fc rgb "red" fs transparent pattern 6
#set obj rect from 10.2485103746 , graph 0 to 10.0071218952 , graph 1 fc rgb "green" fs transparent pattern 7

##set obj rect from 9.96780982962 , graph 0 to 9.71320523766 , graph 1 fc rgb "black" fs transparent pattern 4
##set obj rect from 10.080714138 , graph 0 to 9.82997150597 , graph 1 fc rgb "green" fs transparent pattern 5
##set obj rect from 10.190900276 , graph 0 to 9.95008174255 , graph 1 fc rgb "yellow" fs transparent pattern 6
##set obj rect from 10.2485103746 , graph 0 to 10.0071218952 , graph 1 fc rgb "red" fs transparent pattern 7



set multiplot
# === Large plot ===
unset key
plot "Magpot_angles_L88_mag15_2.d" using 1:2 with lines ls 1 lw 3 lc rgb "#e3f2fd" title "π/8" at end ,\
"Magpot_angles_L88_mag15_2.d" using 1:3 with lines ls 1 lw 3 lc rgb "#90caf9"   title "π/4" at end,\
"Magpot_angles_L88_mag15_2.d" using 1:4 with lines ls 1 lw 3 lc rgb "#1976d2"  title "3π/8" at end,\
"Magpot_angles_L88_mag15_2.d" using 1:5 with lines ls 1 lw 3 lc rgb "#0d47a1"   title "π/2" at end,\

# === Small plot ===
set origin 8.,0.0
set size 3,3
set xrange [8:10]
set yrange [-0.0035:0]
unset xlabel
unset ylabel
unset label


plot "Magpot_angles_L88_mag15_2.d" using 1:2 with lines ls 1 lw 3 lc rgb "purple",\
"Magpot_angles_L88_mag15_2.d" using 1:3 with lines ls 1 lw 3 lc rgb "brown" ,\
"Magpot_angles_L88_mag15_2.d" using 1:4 with lines ls 1 lw 3 lc rgb "cyan" ,\
"Magpot_angles_L88_mag15_2.d" using 1:5 with lines ls 1 lw 3 lc rgb "grey" 

unset multiplot