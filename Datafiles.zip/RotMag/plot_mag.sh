#!/usr/bin/gnuplot -persist

set terminal pdfcairo enhanced
set encoding utf8

set termoption dashed


#set terminal pdfcairo enhanced color dashed font "TeX Gyre Pagella, 14" \
#rounded size 16 cm, 9.6 cm


set output "plot1_magfreq.pdf"

set ylabel "B_{S} [10^{16} G] "
set xlabel "f [Hz]"

#set autoscale
#set grid 
set xrange [0:700]
#set yrange [0.8:3.8]
#set xtics ("0" 0.,"4.41" 4.41,"44.1" 44.1)

set style line 1  lt 1 lw 1 pt 7 pi -1 ps 0.6
set style line 2 dt 2 pt 9 pi -1 ps 0.6
set style line 3 dt 3 pt 9 pi -1 ps 0.6

 set key left top


plot "loopfreq_L55_m12_2.d"  using 12:($2*10**(-16)) with lines ls 1 lc rgb "red"  title "L55"  ,\
"loopfreq_L55_m15_2.d" using 12:($2*10**(-16)) with lines ls 1 lc rgb "blue"  title "" ,\
"loopfreq_L55_m18_2.d" using 12:($2*10**(-16)) with lines ls 1 lc rgb "green" title "",\
"loopfreq_L88_m12_2.d" using 12:($2*10**(-16)) with lines dt 2 lc rgb "red" title "L88" ,\
"loopfreq_L88_m15_2.d" using 12:($2*10**(-16)) with lines dt 2 lc rgb "blue" title "" ,\
"loopfreq_L88_m18_2.d" using 12:($2*10**(-16)) with lines dt 2 lc rgb "green" title "" 
#"loopfreq_L88_m18.d" using 12:($2*10**(-16)) with lines dt 2 lc rgb "green" title "" ,\
#"loopfreq_FSU2R_m12_n.d" using 12:($2*10**(-16)) with lines dt 3 lc rgb "red" title "FSU2R" ,\
#"loopfreq_FSU2R_m15_n.d" using 12:($2*10**(-16)) with lines dt 3 lc rgb "blue" title "" ,\
#"loopfreq_FSU2R_m18_n.d" using 12:($2*10**(-16)) with lines dt 3 lc rgb "green" title ""


#"crust_L55_m18_eq.txt" using 12:($2*10**(-16)) pointtype 7 lc rgb "green" title ""
