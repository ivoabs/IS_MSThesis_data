#! /usr/bin/env python

#DESCRIPTION: 
#para correr:
# chmod +x codename.py
#./codename.py

#WARNING: This program can work  for any type of two column data set. 
	#Here "B" must be understood as the x value of the interpolated function from the set of mu values.
	#(I did not change these names because I was lazy)
 
#MODULES
import subprocess 
import My_Functions
import numpy as np
import matplotlib.pyplot as plt #library used for the plot
import matplotlib.collections as collections
from scipy.interpolate import interp1d


#Include this in My_Functions.py

Bmu_data_file='loopfreq_L88_m18_2.d'
B=2.6*10**(16)
orientation_label=1


def B_to_mu(Bmu_data,Bval,or_label):
 	#f_label -> field label; 
 	#or_label->orientation label(1 for theta=0 and 2 for theta=pi/2)


	f=open(Bmu_data,'r')
	lines2=f.readlines()
	f.close()
	
	for i in range(1,len(lines2)):
		lines2[i]=(lines2[i]).strip()
		lines2[i]=(lines2[i]).split()
		lines2[i]=map(lambda x:float(x),lines2[i])
		#print lines2[i]
	X=[]
	for i in range(1,len(lines2)):
		X.append(lines2[i][0])

	Y=[]
	for i in range(1,len(lines2)):
		Y.append(lines2[i][or_label])

	X=np.array(X)
	Y=np.array(Y)

	f_inter=interp1d(Y,X) 

	return f_inter(Bval)



print B_to_mu(Bmu_data_file,B,orientation_label)

