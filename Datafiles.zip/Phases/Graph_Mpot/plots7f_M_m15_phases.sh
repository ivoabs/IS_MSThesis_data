#!/usr/bin/gnuplot -persist
set terminal pdfcairo enhanced
#set terminal wxt size 350,262 enhanced font 'Verdana,10' persist

set output "Mpotf_L55_m15.pdf"
#set output "Mpotf_FSU2R_m15.txt"


set autoscale
set xlabel "r [km]"
set ylabel "M(r)"

set termoption dashed
set xrange [9.5:12]
set ytics (-0.0036, -0.003)


set style line 1 lt 1


set style rect fc lt -1 fs transparent noborder


set arrow from  11.0874734403 , graph 0 to 11.0874734403 , graph 1  nohead lw 1 fc rgb "#0d47a1" dt 1
set label "droplets" at 11.06,-0.0033 rotate by 90
set arrow from  10.3507885537 , graph 0 to 10.3507885537 , graph 1  nohead lw 2 fc rgb "#0d47a1" dt 1
set label "rods" at 10.3,-0.0033 rotate by 90
set arrow from  10.2858995988 , graph 0 to 10.2858995988 , graph 1  nohead lw 3 fc rgb "#0d47a1" dt 1
set label "slabs" at 10.26,-0.0033 rotate by 90

set arrow from  10.0071218952 , graph 0 to 10.0071218952 , graph 1  nohead lw 4 fc rgb "#0d47a1" dt 1
set label "core" at 9.99,-0.0033 rotate by 90

set arrow from  11.68473728 , graph 0 to 11.68473728 , graph 1  nohead lw 1 fc rgb "#0d47a1" dt 1
set label "outer crust" at 11.66,-0.0033 rotate by 90




plot "Magpot_L55_m15.d" using 1:5 with lines ls 1 lc rgb "#0d47a1"   title "L55"  ,\
#"Magpot_angles_L88_m15.d" using 1:5 with lines dt 2 lc rgb  "#0d47a1" title "π/2"