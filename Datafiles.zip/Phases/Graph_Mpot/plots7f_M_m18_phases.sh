#!/usr/bin/gnuplot -persist
set terminal pdfcairo enhanced
#set terminal wxt size 350,262 enhanced font 'Verdana,10' persist

set output "Mpotf_L55_m18.pdf"
#set output "Mpotf_FSU2R_m15.txt"


set autoscale
set xlabel "r [km]"
set ylabel "M(r)"

set termoption dashed
set xrange [9.5:12]

set ytics (-0.003,-0.0025)

set style line 1 lt 1


set style rect fc lt -1 fs transparent noborder

#L55
#set obj rect from 10.2396913574 , graph 0 to 10.2396913574  , graph 1 fc rgb "#1b5e20" fs transparent pattern 3
#L88
#set obj rect from 10.478990648 , graph 0 to 9.41464001843 , graph 1 fc rgb "#1b5e20" fs transparent pattern 7

#Phases
#___L55:
set arrow from  11.0533968329 , graph 0 to 11.0533968329 , graph 1  nohead lw 1 fc rgb "#1b5e20"dt 1
set label "droplets" at 11.03,-0.003 rotate by 90
set arrow from  10.3294382118 , graph 0 to 10.3294382118 , graph 1  nohead lw 2 fc rgb "#1b5e20" dt 1
set label "rods" at 10.3,-0.003 rotate by 90
set arrow from  10.2710861043 , graph 0 to 10.2710861043 , graph 1  nohead lw 3 fc rgb "#1b5e20" dt 1
set label "slabs" at 10.25,-0.003 rotate by 90

set arrow from  10.0212642584 , graph 0 to 10.0212642584 , graph 1  nohead lw 4 fc rgb "#1b5e20" dt 1
set label "core" at 10.00,-0.003 rotate by 90

set arrow from  11.42201835 , graph 0 to 11.42201835 , graph 1  nohead lw 1 fc rgb "#1b5e20" dt 1
set label "outer crust" at 11.40,-0.003 rotate by 90




plot "Magpot_L55_m18.d" using 1:5 with lines ls 1 lc rgb "#1b5e20" title "L55" ,\
#"Magpot_angles_L88_m18.d" using 1:5 with lines dt 2 lc rgb "#1b5e20"  title "L88"