#!/usr/bin/gnuplot -persist
set terminal pdfcairo enhanced
#set terminal wxt size 350,262 enhanced font 'Verdana,10' persist

set output "Mpotf_L55_m12.pdf"
#set output "Mpotf_FSU2R_m15.txt"


set autoscale
set xlabel "r [km]"
set ylabel "M(r)"

set termoption dashed

set xrange [9.5:12]
set style line 1 lt 1
set ytics (-0.0044,-0.0037)


set style rect fc lt -1 fs transparent noborder

set arrow from  11.1804054179 , graph 0 to 11.1804054179 , graph 1  nohead lw 1 fc rgb "#d50000" dt 1
set label "droplets" at 11.16,-0.0041 rotate by 90
set arrow from  10.2909283849 , graph 0 to 10.2909283849 , graph 1  nohead lw 2 fc rgb "#d50000" dt 1
set label "rods" at 10.27,-0.0041 rotate by 90
set arrow from  10.2131061705 , graph 0 to 10.2131061705 , graph 1  nohead lw 3 fc rgb "#d50000" dt 1
set label "slabs" at 10.19,-0.0041 rotate by 90

set arrow from  9.87274964114 , graph 0 to 9.87274964114 , graph 1  nohead lw 4 fc rgb "#d50000" dt 1
set label "core" at 9.84,-0.0041 rotate by 90

set arrow from  11.93494579 , graph 0 to 11.93494579 , graph 1  nohead lw 1 fc rgb "#d50000" dt 1
set label "outer crust" at 11.91,-0.0041 rotate by 90





plot "Magpot_L55_m12.d" using 1:5 with lines ls 1 lc rgb "#d50000" title "L55",\
#"Magpot_angles_L88_m12.d" using 1:5 with lines dt 2 lc rgb "#d50000" title "π/2"
#set obj rect from 10.1683209478 , graph 0 to 9.87274964114 , graph 1 fc rgb "green" fs transparent pattern 7
