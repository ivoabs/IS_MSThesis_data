#! /usr/bin/env python

#AUTHOR: ivoabs@gmail.com
#DESCRIPTION:
#HOW TO RUN:
	# chmod +x code_name.py
	#./code_name.py 


###########################################
#MODULES
###########################################
import math
import subprocess 
#import numpy as np
#import matplotlib.pyplot as plt #library used for the plot
#import matplotlib.collections as collections


###########################################
#VALUES & FILES
###########################################
file1="crust_angles_L88_m12_phases_mp2.txt"
file2="crust_angles_L88_m15_phases_mp2.txt"
file3="crust_angles_L88_m18_phases_mp2.txt"
whatdoyouwant=1
########################################### MAIN CODE ###########################################
Filelist=[file1,file2,file3]

def extract_Rrho1_0(file,line):
	"extracts R(rho1) at theta=line"
	file=open(file,'r')
	lines=file.readlines()
	line_x=lines[line]
	line_x=line_x.split()
	return line_x[1]

def extract_Rrho2_0(file,line):
	"extracts R(rho2) at theta=line"
	file=open(file,'r')
	lines=file.readlines()
	line_x=lines[line]
	line_x=line_x.split()
	return line_x[2]

def extract_r(file,line,col):
	"extracts R(rho2) at theta=line"
	file=open(file,'r')
	lines=file.readlines()
	line_x=lines[line]
	line_x=line_x.split()
	return line_x[col]

for file in Filelist:
	#print 'set obj rect from '+extract_Rrho1_0(file,2)+' , graph 0 to '+extract_Rrho2_0(file,2)+' , graph 1 fc rgb "black" fs transparent pattern 4'
	#print 'set obj rect from '+extract_Rrho1_0(file,3)+' , graph 0 to '+extract_Rrho2_0(file,3)+' , graph 1 fc rgb "brown" fs transparent pattern 5'
	#print 'set obj rect from '+extract_Rrho1_0(file,4)+' , graph 0 to '+extract_Rrho2_0(file,4)+' , graph 1 fc rgb "red" fs transparent pattern 6'
	#print 'set obj rect from '+extract_Rrho1_0(file,5)+' , graph 0 to '+extract_Rrho2_0(file,5)+' , graph 1 fc rgb "amazon" fs transparent pattern 7'
	print 'set arrow from  '+extract_r(file,5,10)+' , graph 0 to '+extract_r(file,5,10)+' , graph 1  nohead lw 2 fc rgb "#1b5e20" dt 1'
	print 'set label "droplets" at '+extract_r(file,5,10)+',-0.002 rotate by 90'
	print 'set arrow from  '+extract_r(file,5,11)+' , graph 0 to '+extract_r(file,5,11)+' , graph 1  nohead lw 2 fc rgb "#1b5e20" dt 1'
	print 'set label "rods" at '+extract_r(file,5,11)+',-0.002 rotate by 90'
	print 'set arrow from  '+extract_r(file,5,12)+' , graph 0 to '+extract_r(file,5,12)+' , graph 1  nohead lw 2 fc rgb "#1b5e20" dt 1'
	print 'set label "slabs" at '+extract_r(file,5,12)+',-0.002 rotate by 90'
	print 'set arrow from  '+extract_r(file,5,2)+' , graph 0 to '+extract_r(file,5,2)+' , graph 1  nohead lw 2 fc rgb "#1b5e20" dt 1'
	print 'set label "core" at '+extract_r(file,5,2)+',-0.002 rotate by 90'
	print 'set arrow from  '+extract_r(file,5,6)+' , graph 0 to '+extract_r(file,5,6)+' , graph 1  nohead lw 2 fc rgb "#1b5e20" dt 1'
	print 'set label "outer crust" at '+extract_r(file,5,6)+',-0.002 rotate by 90'

 
	print ""
	print ""