#!/usr/bin/gnuplot -persist
set terminal pdfcairo enhanced
#set terminal wxt size 350,262 enhanced font 'Verdana,10' persist

set output "Mpotf_all_m12.pdf"
#set output "Mpotf_FSU2R_m15.txt"


set autoscale
set xlabel "r [km]"
set ylabel "M(r)"

set termoption dashed

set style line 1 lt 1


set style rect fc lt -1 fs transparent noborder

set arrow from  13.62385321 , graph 0 to 13.62385321 , graph 1  nohead lw 2 fc rgb "#1b5e20" dt 1
set label "rods" at 13.62385321,-0.002 rotate by 90
set arrow from  13.62385321 , graph 0 to 13.62385321 , graph 1  nohead lw 2 fc rgb "#1b5e20" dt 1
set label "droplets" at 13.62385321,-0.002 rotate by 90
set arrow from  13.62385321 , graph 0 to 13.62385321 , graph 1  nohead lw 2 fc rgb "#1b5e20" dt 1
set label "slabs" at 13.62385321,-0.002 rotate by 90

plot "Magpot_L55_m12.d" using 1:5 with lines ls 1 lc rgb "#d50000" title "π/2",\
"Magpot_angles_L88_m12.d" using 1:5 with lines dt 2 lc rgb "#d50000" title "π/2"
#set obj rect from 10.1683209478 , graph 0 to 9.87274964114 , graph 1 fc rgb "green" fs transparent pattern 7
