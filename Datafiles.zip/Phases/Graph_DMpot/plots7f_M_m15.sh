#!/usr/bin/gnuplot -persist
set terminal pdfcairo enhanced
#set terminal wxt size 350,262 enhanced font 'Verdana,10' persist

set output "Mpotf_all_m15.pdf"
#set output "Mpotf_FSU2R_m15.txt"


set autoscale
set xlabel "r [km]"
set ylabel "M(r)"

set termoption dashed

set style line 1 lt 1


set style rect fc lt -1 fs transparent noborder

#L55
set obj rect from 10.2485103746 , graph 0 to 10.0071218952 , graph 1 fc rgb "#0d47a1"  fs transparent pattern 3
#L88
set obj rect from 10.8337749684 , graph 0 to 9.55214807216 , graph 1 fc rgb "#0d47a1"  fs transparent pattern 7

plot "Magpot_L55_m15.d" using 1:5 with lines ls 1 lc rgb "#0d47a1"   title "π/2"  ,\
"Magpot_angles_L88_m15.d" using 1:5 with lines dt 2 lc rgb  "#0d47a1" title "π/2"