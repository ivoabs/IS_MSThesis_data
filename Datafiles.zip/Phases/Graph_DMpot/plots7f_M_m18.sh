#!/usr/bin/gnuplot -persist
set terminal pdfcairo enhanced
#set terminal wxt size 350,262 enhanced font 'Verdana,10' persist

set output "Mpotf_all_m18.pdf"
#set output "Mpotf_FSU2R_m15.txt"


set autoscale
set xlabel "r [km]"
set ylabel "M(r)"

set termoption dashed

set style line 1 lt 1


set style rect fc lt -1 fs transparent noborder

#L55
set obj rect from 10.2396913574 , graph 0 to 10.0212642584 , graph 1 fc rgb "#1b5e20" fs transparent pattern 3
#L88
set obj rect from 10.478990648 , graph 0 to 9.41464001843 , graph 1 fc rgb "#1b5e20" fs transparent pattern 7

plot "Magpot_L55_m18.d" using 1:5 with lines ls 1 lc rgb "#1b5e20" title "L55" ,\
"Magpot_angles_L88_m18.d" using 1:5 with lines dt 2 lc rgb "#1b5e20"  title "L88"