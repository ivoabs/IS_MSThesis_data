#!/usr/bin/gnuplot -persist
#set terminal pdfcairo enhanced
set terminal pdfcairo enhanced

set encoding utf8
set termoption dashed

set output "plots6_R2.pdf"

#set polar
set autoscale
#set xlabel "Polar angle [rad]"
set ylabel "R_2(θ) [km]"
set xlabel "θ"

#set xlabel "[km]"
#set ylabel "[km]"

#set grid 
#set grid polar
#set size square 
#set label

#set yrange [0:15]
#set xrange [-15:15]

#set angles radians
#show angles

#set xrange [50:120]
#set yrange [0.6:1.7]
#set ytics (1.0,1.4,1.8,2.2,2.6,3.,3.4)

#R=11.36193055
#R_1=10.1377953396


set style line 1 lc rgb 'red' lt 1 lw 1 pi -1 ps 0.6
set style line 2 dt 2  pi -1 ps 0.6

set style line 3 lc rgb 'red' lt 1 pt 7 lw 1 pi -1 ps 0.4
set style line 4 lc rgb 'red' lt 1 pt 9 lw 1 pi -1 ps 0.4
set style line 5 lc rgb 'red' lt 1 pt 5 lw 1 pi -1 ps 0.4




#set style line 3 lt 2 lc rgb "yellow" lw 3

set xtics ("0" 0., "π/4" 0.785398163397, "π/2" 1.57079632679, "3π/4" 2.35619449019, "π" 3.14159265359)

#plot "B_0.txt" pointtype 7 ps 1 lc rgb "black" title "B*=0", "B_10e2.txt" pointtype 7 p2 1 lc rgb "blue" title "B*=10^2" , "B_10e3.txt" pointtype 7 ps 1 lc rgb "red" title "B*=10^3", \
#"B_10e3_2.txt" pointtype 5 ps 1 lc rgb "red" title "B*=10^3" ,\
#'Ae3.txt' with linespoints ls 1 title "Artigo B*=10^3",\
#'Ae3_2.txt' with linespoints ls 1 title "Artigo B*=10^3"

#L55: R 	R1
#11.79095258	9.92607031239
#11.59282999	10.1307990966
#11.36193055	10.1377953396
#FSU2R: R 	R1
#11.18962185 	9.71069933251
#10.83490128 	9.65988812459
#10.3801158 	9.30539694477

plot "crust_angles_L55_m12_2p.txt" using 1:($3) with lines ls 1  lc rgb "red" title "" ,\
"crust_angles_L55_m15_2p.txt" using 1:($3) with lines ls 1 lc rgb "blue"  title "",\
"crust_angles_L55_m18_2p.txt" using 1:($3) with lines ls 1 lc rgb "green" title "",\
"crust_angles_L88_m12.txt" using 1:($3) with lines ls 2  lc rgb "red" title "" ,\
"crust_angles_L88_m15.txt" using 1:($3) with lines ls 2 lc rgb "blue"  title "",\
"crust_angles_L88_m18.txt" using 1:($3) with lines ls 2 lc rgb "green" title ""




#"crust_angles_FSU2R_m12_2p.txt" using 1:($7/11.18962185) with lines ls 2  lc rgb "red" title "" ,\
#"crust_angles_FSU2R_m15_2p.txt" using 1:($7/10.83490128) with lines ls 2 lc rgb "blue"  title "",\
#"crust_angles_FSU2R_m18_2p.txt" using 1:($7/10.3801158) with lines ls 2 lc rgb "green" title ""