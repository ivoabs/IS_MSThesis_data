#!/usr/bin/gnuplot -persist
set terminal pdfcairo enhanced
set output "plots5_L88.pdf"

set autoscale
set xlabel "r [km]"
set ylabel "{/Symbol r} [fm^{-3}]"

set xrange [0:12]
set yrange [-0.05:0.35]

set zeroaxis
set style line 1 lt 1


#set style rect fc lt -1 fs solid 0.5 noborder

#set obj rect from 9.38832415219 , graph 0 to 9.37476509965 , graph 1 fc rgb "red" 
#set obj rect from 9.45362075868 , graph 0 to 9.44091693809 , graph 1 fc rgb "blue" 
#set obj rect from 9.32133008478 , graph 0 to 9.31148594752 , graph 1 fc rgb "green" 



set style rect fc lt -1 fs transparent noborder

set obj rect from 10.16355062 , graph 0 to 8.69499789902 , graph 1 fc rgb  "red" fs pattern 4 transparent
set obj rect from 10.4383187202 , graph 0 to 9.15585661511 , graph 1 fc rgb  "blue" fs pattern 5 transparent
set obj rect from 10.4393521595 , graph 0 to 9.37653236981 , graph 1 fc rgb  "green" fs pattern 15 transparent 




unset key
plot "prof_density_L88_m12.d" using 1:3 with lines ls  1 lc rgb "red" title "" ,\
"prof_density_L88_m15.d" using 1:3 with lines ls 1 lc rgb "blue" title "",\
"prof_density_L88_m18.d" using 1:3 with lines ls  1 lc rgb "green" title "" 
