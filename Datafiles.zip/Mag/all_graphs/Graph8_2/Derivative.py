#! /usr/bin/env python

#DESCRIPTION:Numerical derivative (magnetic potential) 
#HOW TO RUN:
	# chmod +x code_name.py
	#./code_name.py 


###########################################
#MODULES
###########################################
import math
import subprocess 
import My_Functions
import numpy as np
import matplotlib.pyplot as plt #library used for the plot
import matplotlib.collections as collections


###########################################
#VALUES & FILES
###########################################
file="Magpot_angles_L88_m18.d"
output="DMag_L88_m18.d"
########################################### MAIN CODE ###########################################
f=open(file,"r")
lines=f.readlines()
f.close()

lines=lines[1:]
lines=map(lambda x: x.strip("\n"),lines)
lines=map(lambda x: x.split(),lines)

def getcolumn(list,column):
	"returns the desired column of the list of lists"
	L=[]
	for x in list:
		L.append(x[column])
	return L

X=getcolumn(lines,0)
Y1,Y2,Y3,Y4=getcolumn(lines,1),getcolumn(lines,2),getcolumn(lines,3),getcolumn(lines,4)

X=np.array(X,dtype=np.float)
Y1,Y2,Y3,Y4=np.array(Y1,dtype=np.float),np.array(Y2,dtype=np.float),np.array(Y3,dtype=np.float),np.array(Y4,dtype=np.float)

df1,df2,df3,df4=np.gradient(Y1,X),np.gradient(Y2,X),np.gradient(Y3,X),np.gradient(Y4,X)

f=open(output, "w")
for i in range(len(X)):
	f.write(str(X[i])+" "+str(df1[i])+" "+str(df2[i])+" "+str(df3[i])+" "+str(df4[i])+"\n")
f.close()



