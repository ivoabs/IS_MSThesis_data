#!/usr/bin/gnuplot -persist

set terminal pdfcairo enhanced
set encoding utf8

set termoption dashed


#set terminal pdfcairo enhanced color dashed font "TeX Gyre Pagella, 14" \
#rounded size 16 cm, 9.6 cm


set output "plots2_DR2_21.pdf"

set xlabel "B_S [10^{15} G] "
set ylabel "{/Symbol D}R_2 [km]"

#set autoscale
#set grid 
#set xrange [0:45]
#set yrange [0.8:3.8]
set xtics ("0" 0.,"1" 4.41,"5" 22.05,"10" 44.1)

set style line 1 lc rgb 'red' lt 1 lw 1 pt 7 pi -1 ps 0.6
set style line 2 dt 2 pt 9 pi -1 ps 0.6

set nokey


plot "crust_L55_m12_pol2.txt"  using (10**(-15) * $14):6 with linespoints ls 1  lc rgb "red"  title "L=55; M_{b}=1.2M_{☉}", \
"crust_L55_m15_pol2.txt" using (10**(-15) * $14):6 with linespoints ls 1     lc rgb "blue"  title "L=55; M_{b}=1.5M_{☉}",\
"crust_L55_m18_pol2.txt" using (10**(-15) * $14):6 with linespoints ls 1  lc rgb "green" title "L=55; M_{b}=1.8M_{☉}",\
#"crust_L88_m12_pol2.txt" using (10**(-15) * $14):6 with linespoints ls 2  lc rgb "red" title "L=88; M_{b}=1.2M_{☉}",\
#"crust_L88_m15_pol2.txt" using (10**(-15) * $14):6 with linespoints ls 2 lc rgb "blue" title "L=88; M_{b}=1.5M_{☉}",\
#"crust_L88_m18_pol2.txt" using (10**(-15) * $14):6 with linespoints ls 2  lc rgb "green" title "L=88; M_{b}=1.8M_{☉}"


#"crust_L55_m18_eq.txt" using (10**(-15) * $14):5 pointtype 7 lc rgb "green" title ""
