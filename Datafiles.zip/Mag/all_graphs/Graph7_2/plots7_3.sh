#!/usr/bin/gnuplot -persist
set terminal pdfcairo enhanced
#set terminal wxt size 350,262 enhanced font 'Verdana,10' persist

set output "Mpotf_L55_m12.pdf"
#set output "Mpotf_L88_m15.txt"


#set autoscale
set xlabel "r [km]"
set ylabel "M(r)"

set yrange [-0.005:0]
set xrange [0:12]
set key left bottom

set style line 1 lt 1

set style rect fc lt -1 fs transparent solid 0.5 noborder

#set obj rect from 9.72046646696 , graph 0 to 9.41562311072 , graph 1 fc rgb "black" fs transparent pattern 4
#set obj rect from 9.90516087378 , graph 0 to 9.5982965591 , graph 1 fc rgb "brown" fs transparent pattern 5
#set obj rect from 10.0884440368 , graph 0 to 9.79278057575 , graph 1 fc rgb "red" fs transparent pattern 6
#set obj rect from 10.1683209478 , graph 0 to 9.87274964114 , graph 1 fc rgb "green" fs transparent pattern 7

##set obj rect from 9.72046646696 , graph 0 to 9.41562311072 , graph 1 fc rgb "black" fs transparent pattern 4    #"#ff9494 "
##set obj rect from 9.90516087378 , graph 0 to 9.5982965591 , graph 1 fc rgb  "green"  fs transparent pattern 5   #"#ef9a9a"
##set obj rect from 10.0884440368 , graph 0 to 9.79278057575 , graph 1 fc rgb "yellow" fs transparent pattern 6	  #"#ef5350"
##set obj rect from 10.1683209478 , graph 0 to 9.87274964114 , graph 1 fc rgb "red" 	fs transparent pattern 7  #"#d50000"



set multiplot
# === Large plot ===
 #
plot "Magpot_L55_m12.d" using 1:2 with lines ls 1 lw 3 lc rgb "#ff9494 "  title "π/8"  ,\
"Magpot_L55_m12.d" using 1:3 with lines ls 1 lw 3 lc rgb "#ef9a9a" title "π/4"   ,\
"Magpot_L55_m12.d" using 1:4 with lines ls 1 lw 3 lc rgb "#ef5350" title "3π/8"   ,\
"Magpot_L55_m12.d" using 1:5 with lines ls 1 lw 3 lc rgb "#d50000" title "π/2"   ,\

# === Small plot ===
set origin 8.,0.0
set size 3,3
set xrange [0:12]
set yrange [-0.005:0]
unset xlabel
unset ylabel
unset label


plot "Magpot_L55_m12.d" using 1:2 with lines ls 1 lw 3 lc rgb "purple",\
"Magpot_L55_m12.d" using 1:3 with lines ls 1 lw 3 lc rgb "brown" ,\
"Magpot_L55_m12.d" using 1:4 with lines ls 1 lw 3 lc rgb "cyan" ,\
"Magpot_L55_m12.d" using 1:5 with lines ls 1 lw 3 lc rgb "grey" 

unset multiplot

#######################################################################################
#######################################  PLOT  2  #####################################
reset

set terminal pdfcairo enhanced
#set terminal wxt size 350,262 enhanced font 'Verdana,10' persist

set output "Mpotf_L55_m15.pdf"
#set output "Mpotf_L88_m15.txt"

set key left bottom

#set autoscale
set xlabel "r [km]"
set ylabel "M(r)"

set yrange [-0.005:0]
set xrange [0:12]


set style line 1 lt 1

set style rect fc lt -1 fs transparent solid 0.5 noborder


#set obj rect from 9.96780982962 , graph 0 to 9.71320523766 , graph 1 fc rgb "black" fs transparent pattern 4
#set obj rect from 10.080714138 , graph 0 to 9.82997150597 , graph 1 fc rgb "brown" fs transparent pattern 5
#set obj rect from 10.190900276 , graph 0 to 9.95008174255 , graph 1 fc rgb "red" fs transparent pattern 6
#set obj rect from 10.2485103746 , graph 0 to 10.0071218952 , graph 1 fc rgb "green" fs transparent pattern 7

##set obj rect from 9.96780982962 , graph 0 to 9.71320523766 , graph 1 fc rgb "black" fs transparent pattern 4
##set obj rect from 10.080714138 , graph 0 to 9.82997150597 , graph 1 fc rgb "green" fs transparent pattern 5
##set obj rect from 10.190900276 , graph 0 to 9.95008174255 , graph 1 fc rgb "yellow" fs transparent pattern 6
##set obj rect from 10.2485103746 , graph 0 to 10.0071218952 , graph 1 fc rgb "red" fs transparent pattern 7

set multiplot
# === Large plot ===
 #
plot "Magpot_L55_m15.d" using 1:2 with lines ls 1 lw 3 lc rgb "#e3f2fd" title "π/8"  ,\
"Magpot_L55_m15.d" using 1:3 with lines ls 1 lw 3 lc rgb "#90caf9"   title "π/4"   ,\
"Magpot_L55_m15.d" using 1:4 with lines ls 1 lw 3 lc rgb "#1976d2"  title "3π/8"   ,\
"Magpot_L55_m15.d" using 1:5 with lines ls 1 lw 3 lc rgb "#0d47a1"   title "π/2"   ,\

# === Small plot ===
set origin 8.,0.0
set size 3,3
set yrange [0:12]
set xrange [-0.005:0]
unset xlabel
unset ylabel
unset label


plot "Magpot_L55_m15.d" using 1:2 with lines ls 1 lw 3 lc rgb "purple",\
"Magpot_L55_m15.d" using 1:3 with lines ls 1 lw 3 lc rgb "brown" ,\
"Magpot_L55_m15.d" using 1:4 with lines ls 1 lw 3 lc rgb "cyan" ,\
"Magpot_L55_m15.d" using 1:5 with lines ls 1 lw 3 lc rgb "grey" 

unset multiplot

#######################################################################################
#######################################  PLOT  3  #####################################
reset

set terminal pdfcairo enhanced
#set terminal wxt size 350,262 enhanced font 'Verdana,10' persist

set output "Mpotf_L55_m18.pdf"
#set output "Mpotf_L88_m15.txt"

set key left bottom
#set autoscale
set xlabel "r [km]"
set ylabel "M(r)"

set yrange [-0.005:0]
set xrange [0:12]

set style line 1 lt 1

set style rect fc lt -1 fs solid 0.5 noborder


#set obj rect from 10.0109575441 , graph 0 to 9.82015704618 , graph 1 fc rgb "black" fs transparent pattern 4
#set obj rect from 10.1152834132 , graph 0 to 9.89707677354 , graph 1 fc rgb "brown" fs transparent pattern 5
#set obj rect from 10.1863269651 , graph 0 to 9.98995185913 , graph 1 fc rgb "red" fs transparent pattern 6
#set obj rect from 10.2396913574 , graph 0 to 10.0212642584 , graph 1 fc rgb "green" fs transparent pattern 7

##set obj rect from 10.0109575441 , graph 0 to 9.82015704618 , graph 1 fc rgb "black" fs transparent pattern 4
##set obj rect from 10.1152834132 , graph 0 to 9.89707677354 , graph 1 fc rgb "green" fs transparent pattern 5
##set obj rect from 10.1863269651 , graph 0 to 9.98995185913 , graph 1 fc rgb "yellow" fs transparent pattern 6
##set obj rect from 10.2396913574 , graph 0 to 10.0212642584 , graph 1 fc rgb "red" fs transparent pattern 7


set multiplot
# === Large plot ===
 #
plot "Magpot_L55_m18.d" using 1:2 with lines ls 1 lw 3 lc rgb "#9cffac"  title "π/8"  ,\
"Magpot_L55_m18.d" using 1:3 with lines ls 1 lw 3 lc rgb "#a5d6a7"  title "π/4"   ,\
"Magpot_L55_m18.d" using 1:4 with lines ls 1 lw 3 lc rgb "#4caf50" title "3π/8"   ,\
"Magpot_L55_m18.d" using 1:5 with lines ls 1 lw 3 lc rgb "#1b5e20" title "π/2"   ,\

# === Small plot ===
set origin 8.,0.0
set size 3,3
set yrange [8:10]
set xrange [-0.0035:0]
unset xlabel
unset ylabel
unset label


plot "Magpot_L55_m18.d" using 1:2 with lines ls 1 lw 3 lc rgb "purple",\
"Magpot_L55_m18.d" using 1:3 with lines ls 1 lw 3 lc rgb "brown" ,\
"Magpot_L55_m18.d" using 1:4 with lines ls 1 lw 3 lc rgb "cyan" ,\
"Magpot_L55_m18.d" using 1:5 with lines ls 1 lw 3 lc rgb "grey" 

unset multiplot

#######################################################################################
#######################################  PLOT  4  #####################################
reset
set terminal pdfcairo enhanced
#set terminal wxt size 350,262 enhanced font 'Verdana,10' persist


set output "Mpotf_L88_m12.pdf"
#set output "Mpotf_L88_m15.txt"
set key left bottom

#set autoscale
set xlabel "r [km]"
set ylabel "M(r)"

set yrange [-0.002:0]
set xrange [0:12]

set style line 1 lt 1

set style rect fc lt -1 fs transparent solid 0.5 noborder

#set obj rect from 10.2748475732 , graph 0 to 8.78025978981 , graph 1 fc rgb "black" fs transparent pattern 4
#set obj rect from 10.4889285211 , graph 0 to 8.9893829276 , graph 1 fc rgb "brown" fs transparent pattern 5
#set obj rect from 10.7051248056 , graph 0 to 9.20965545193 , graph 1 fc rgb "red" fs transparent pattern 6
#set obj rect from 10.8048404914 , graph 0 to 9.30535241915 , graph 1 fc rgb "green" fs transparent pattern 7


##set obj rect from 9.49020630025, graph 0 to 9.4773057915, graph 1 fc rgb "black" fs transparent pattern 3 
##set obj rect from 9.58681649466, graph 0 to 9.57244014011, graph 1 fc rgb "green" fs transparent pattern 3
##set obj rect from 9.67578287661, graph 0 to 9.66128398176, graph 1 fc rgb "yellow" fs transparent pattern 3
##set obj rect from 9.71203573459, graph 0 to 9.69763662593, graph 1 fc rgb "red" fs transparent pattern 3


set multiplot
# === Large plot ===
 #
plot "Magpot_angles_L88_m12.d" using 1:2 with lines ls 1 lw 3 lc rgb  "#ff9494 "  title "π/8"  ,\
"Magpot_angles_L88_m12.d" using 1:3 with lines ls 1 lw 3 lc rgb "#ef9a9a" title "π/4"   ,\
"Magpot_angles_L88_m12.d" using 1:4 with lines ls 1 lw 3 lc rgb "#ef5350" title "3π/8"   ,\
"Magpot_angles_L88_m12.d" using 1:5 with lines ls 1 lw 3 lc rgb "#d50000" title "π/2"   ,\

# === Small plot ===
set origin 8.,0.0
set size 3,3
set yrange [8:10]
set xrange [-0.0015:0]
unset xlabel
unset ylabel
unset label


plot "Magpot_angles_L88_m12.d" using 1:2 with lines ls 1 lw 3 lc rgb "purple",\
"Magpot_angles_L88_m12.d" using 1:3 with lines ls 1 lw 3 lc rgb "brown" ,\
"Magpot_angles_L88_m12.d" using 1:4 with lines ls 1 lw 3 lc rgb "cyan" ,\
"Magpot_angles_L88_m12.d" using 1:5 with lines ls 1 lw 3 lc rgb "grey" 

unset multiplot


#######################################################################################
#######################################  PLOT  5  #####################################
reset

set terminal pdfcairo enhanced
#set terminal wxt size 350,262 enhanced font 'Verdana,10' persist

set output "Mpotf_L88_m15.pdf"
#set output "Mpotf_L88_m15.txt"

set key left bottom
set autoscale
set xlabel "r [km]"
set ylabel "M(r)"

set yrange [-0.002:0]
set xrange [0:12]


set style line 1 lt 1

set style rect fc lt -1 fs transparent solid 0.5 noborder

#set obj rect from 10.4932582465 , graph 0 to 9.21155618651 , graph 1 fc rgb "black" fs transparent pattern 4
#set obj rect from 10.6311893947 , graph 0 to 9.34953942649 , graph 1 fc rgb "brown" fs transparent pattern 5
#set obj rect from 10.7709356906 , graph 0 to 9.49206472387 , graph 1 fc rgb "red" fs transparent pattern 6
#set obj rect from 10.8337749684 , graph 0 to 9.55214807216 , graph 1 fc rgb "green" fs transparent pattern 7

##set obj rect from 9.49020630025, graph 0 to 9.4773057915, graph 1 fc rgb "black" fs transparent pattern 3
##set obj rect from 9.58681649466, graph 0 to 9.57244014011, graph 1 fc rgb "green" fs transparent pattern 3
##set obj rect from 9.67578287661, graph 0 to 9.66128398176, graph 1 fc rgb "yellow" fs transparent pattern 3
##set obj rect from 9.71203573459, graph 0 to 9.69763662593, graph 1 fc rgb "red" fs transparent pattern 3


set multiplot
# === Large plot ===
 #
plot "Magpot_angles_L88_m15.d" using 1:2 with lines ls 1 lw 3 lc rgb  "#e3f2fd"  title "π/8"  ,\
"Magpot_angles_L88_m15.d" using 1:3 with lines ls 1 lw 3 lc rgb "#90caf9" title "π/4"   ,\
"Magpot_angles_L88_m15.d" using 1:4 with lines ls 1 lw 3 lc rgb "#1976d2"  title "3π/8"   ,\
"Magpot_angles_L88_m15.d" using 1:5 with lines ls 1 lw 3 lc rgb  "#0d47a1" title "π/2"   ,\

# === Small plot ===
set origin 8.,0.0
set size 3,3
set xrange [8:10]
set yrange [-0.0035:0]
unset xlabel
unset ylabel
unset label


plot "Magpot_angles_L88_m15.d" using 1:2 with lines ls 1 lw 3 lc rgb "purple",\
"Magpot_angles_L88_m15.d" using 1:3 with lines ls 1 lw 3 lc rgb "brown" ,\
"Magpot_angles_L88_m15.d" using 1:4 with lines ls 1 lw 3 lc rgb "cyan" ,\
"Magpot_angles_L88_m15.d" using 1:5 with lines ls 1 lw 3 lc rgb "grey" 

unset multiplot

#######################################################################################
#######################################  PLOT  6  #####################################
reset


set terminal pdfcairo enhanced
#set terminal wxt size 350,262 enhanced font 'Verdana,10' persist
set key left bottom
set output "Mpotf_L88_m18.pdf"
#set output "Mpotf_L88_m15.txt"


set autoscale
set xlabel "r [km]"
set ylabel "M(r)"

set yrange [-0.002:0]
set xrange [0:12]


set style line 1 lt 1

set style rect fc lt -1 fs transparent solid 0.5 noborder

##set obj rect from 10.478990648 , graph 0 to 9.41464001843 , graph 1 fc rgb "black" fs transparent pattern 4
##set obj rect from 10.5797189819 , graph 0 to 9.5090969715 , graph 1 fc rgb "brown" fs transparent pattern 5
##set obj rect from 10.6748829445 , graph 0 to 9.60454859386 , graph 1 fc rgb "red" fs transparent pattern 6
##set obj rect from 10.71591334 , graph 0 to 9.6445240751 , graph 1 fc rgb "green" fs transparent pattern 7


##set obj rect from 9.49020630025, graph 0 to 9.4773057915, graph 1 fc rgb "black" fs transparent pattern 3
##set obj rect from 9.58681649466, graph 0 to 9.57244014011, graph 1 fc rgb "green" fs transparent pattern 3
##set obj rect from 9.67578287661, graph 0 to 9.66128398176, graph 1 fc rgb "yellow" fs transparent pattern 3
##set obj rect from 9.71203573459, graph 0 to 9.69763662593, graph 1 fc rgb "red" fs transparent pattern 3


set multiplot
# === Large plot ===
 #
plot "Magpot_angles_L88_m18.d" using 1:2 with lines ls 1 lw 3 lc rgb  "#9cffac"  title "π/8"  ,\
"Magpot_angles_L88_m18.d" using 1:3 with lines ls 1 lw 3 lc rgb "#a5d6a7"  title "π/4"   ,\
"Magpot_angles_L88_m18.d" using 1:4 with lines ls 1 lw 3 lc rgb "#4caf50"   title "3π/8"   ,\
"Magpot_angles_L88_m18.d" using 1:5 with lines ls 1 lw 3 lc rgb "#1b5e20"  title "π/2"   ,\

# === Small plot ===
set origin 8.,0.0
set size 3,3
set yrange [8:10]
set xrange [-0.0035:0]
unset xlabel
unset ylabel
unset label


plot "Magpot_angles_L88_m18.d" using 1:2 with lines ls 1 lw 3 lc rgb "purple",\
"Magpot_angles_L88_m18.d" using 1:3 with lines ls 1 lw 3 lc rgb "brown" ,\
"Magpot_angles_L88_m18.d" using 1:4 with lines ls 1 lw 3 lc rgb "cyan" ,\
"Magpot_angles_L88_m18.d" using 1:5 with lines ls 1 lw 3 lc rgb "grey" 

unset multiplot