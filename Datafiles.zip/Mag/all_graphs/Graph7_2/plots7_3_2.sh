#!/usr/bin/gnuplot -persist
set terminal pdfcairo enhanced
#set terminal wxt size 350,262 enhanced font 'Verdana,10' persist

set output "Mpotf_L55.pdf"
#set output "Mpotf_L88_m15.txt"


set autoscale
set xlabel "r [km]"
set ylabel "M(r)"

set style line 1 lt 1

set style rect fc lt -1 fs transparent solid 0.5 noborder

#set obj rect from 9.72046646696 , graph 0 to 9.41562311072 , graph 1 fc rgb "black" fs transparent pattern 4
#set obj rect from 9.90516087378 , graph 0 to 9.5982965591 , graph 1 fc rgb "brown" fs transparent pattern 5
#set obj rect from 10.0884440368 , graph 0 to 9.79278057575 , graph 1 fc rgb "red" fs transparent pattern 6
#set obj rect from 10.1683209478 , graph 0 to 9.87274964114 , graph 1 fc rgb "green" fs transparent pattern 7

##set obj rect from 9.72046646696 , graph 0 to 9.41562311072 , graph 1 fc rgb "black" fs transparent pattern 4    #"#ffebee"
##set obj rect from 9.90516087378 , graph 0 to 9.5982965591 , graph 1 fc rgb  "green"  fs transparent pattern 5   #"#ef9a9a"
##set obj rect from 10.0884440368 , graph 0 to 9.79278057575 , graph 1 fc rgb "yellow" fs transparent pattern 6	  #"#ef5350"
##set obj rect from 10.1683209478 , graph 0 to 9.87274964114 , graph 1 fc rgb "red" 	fs transparent pattern 7  #"#d50000"

set multiplot
# === Large plot ===
unset key
plot "Magpot_L55_m12.d" using 1:2 with lines ls 1 lc rgb "#ffebee"  title "π/8" at end ,\
"Magpot_L55_m12.d" using 1:3 with lines ls 1 lc rgb "#ef9a9a" title "π/4" at end,\
"Magpot_L55_m12.d" using 1:4 with lines ls 1 lc rgb "#ef5350" title "3π/8" at end,\
"Magpot_L55_m12.d" using 1:5 with lines ls 1 lc rgb "#d50000" title "π/2" at end,\
"Magpot_L55_m15.d" using 1:2 with lines ls 1 lc rgb "#e3f2fd" title "" at end ,\
"Magpot_L55_m15.d" using 1:3 with lines ls 1 lc rgb "#90caf9"   title "" at end,\
"Magpot_L55_m15.d" using 1:4 with lines ls 1 lc rgb "#1976d2"  title "" at end,\
"Magpot_L55_m15.d" using 1:5 with lines ls 1 lc rgb "#0d47a1"   title "" at end,\
"Magpot_L55_m18.d" using 1:2 with lines ls 1 lc rgb "#e8f5e9"  title "" at end ,\
"Magpot_L55_m18.d" using 1:3 with lines ls 1 lc rgb "#a5d6a7"  title "" at end,\
"Magpot_L55_m18.d" using 1:4 with lines ls 1 lc rgb "#4caf50" title "" at end,\
"Magpot_L55_m18.d" using 1:5 with lines ls 1 lc rgb "#1b5e20" title "" at end


unset multiplot


#######################################################################################
#######################################  PLOT  4  #####################################
reset
set terminal pdfcairo enhanced
#set terminal wxt size 350,262 enhanced font 'Verdana,10' persist


set output "Mpotf_L88.pdf"
#set output "Mpotf_L88_m15.txt"


set autoscale
set xlabel "r [km]"
set ylabel "M(r)"


set style line 1 lt 1

set style rect fc lt -1 fs transparent solid 0.5 noborder

#set obj rect from 10.2748475732 , graph 0 to 8.78025978981 , graph 1 fc rgb "black" fs transparent pattern 4
#set obj rect from 10.4889285211 , graph 0 to 8.9893829276 , graph 1 fc rgb "brown" fs transparent pattern 5
#set obj rect from 10.7051248056 , graph 0 to 9.20965545193 , graph 1 fc rgb "red" fs transparent pattern 6
#set obj rect from 10.8048404914 , graph 0 to 9.30535241915 , graph 1 fc rgb "green" fs transparent pattern 7


##set obj rect from 9.49020630025, graph 0 to 9.4773057915, graph 1 fc rgb "black" fs transparent pattern 3 
##set obj rect from 9.58681649466, graph 0 to 9.57244014011, graph 1 fc rgb "green" fs transparent pattern 3
##set obj rect from 9.67578287661, graph 0 to 9.66128398176, graph 1 fc rgb "yellow" fs transparent pattern 3
##set obj rect from 9.71203573459, graph 0 to 9.69763662593, graph 1 fc rgb "red" fs transparent pattern 3


set multiplot
# === Large plot ===
unset key
plot "Magpot_angles_L88_m12.d" using 1:2 with lines ls 1 lc rgb  "#ffebee"  title "π/8" at end ,\
"Magpot_angles_L88_m12.d" using 1:3 with lines ls 1 lc rgb "#ef9a9a" title "π/4" at end,\
"Magpot_angles_L88_m12.d" using 1:4 with lines ls 1 lc rgb "#ef5350" title "3π/8" at end,\
"Magpot_angles_L88_m12.d" using 1:5 with lines ls 1 lc rgb "#d50000" title "π/2" at end,\
"Magpot_angles_L88_m15.d" using 1:2 with lines ls 1 lc rgb  "#e3f2fd"  title "" at end ,\
"Magpot_angles_L88_m15.d" using 1:3 with lines ls 1 lc rgb "#90caf9" title "" at end,\
"Magpot_angles_L88_m15.d" using 1:4 with lines ls 1 lc rgb "#1976d2"  title "" at end,\
"Magpot_angles_L88_m15.d" using 1:5 with lines ls 1 lc rgb  "#0d47a1" title "" at end,\
"Magpot_angles_L88_m18.d" using 1:2 with lines ls 1 lc rgb  "#e8f5e9"  title "" at end ,\
"Magpot_angles_L88_m18.d" using 1:3 with lines ls 1 lc rgb "#a5d6a7"  title "" at end,\
"Magpot_angles_L88_m18.d" using 1:4 with lines ls 1 lc rgb "#4caf50"   title "" at end,\
"Magpot_angles_L88_m18.d" using 1:5 with lines ls 1 lc rgb "#1b5e20"  title "" at end

unset multiplot
