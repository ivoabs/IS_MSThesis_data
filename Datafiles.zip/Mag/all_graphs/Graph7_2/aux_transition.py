#! /usr/bin/env python

#AUTHOR: ivoabs@gmail.com
#DESCRIPTION:
#HOW TO RUN:
	# chmod +x code_name.py
	#./code_name.py 


###########################################
#MODULES
###########################################
import math
import subprocess 
#import numpy as np
#import matplotlib.pyplot as plt #library used for the plot
#import matplotlib.collections as collections


###########################################
#VALUES & FILES
###########################################
file1="crust_angles_L55_m12_mp.txt"
file2="crust_angles_L55_m15_mp.txt"
file3="crust_angles_L55_m18_mp.txt"
whatdoyouwant=1
########################################### MAIN CODE ###########################################
Filelist=[file1,file2,file3]

def extract_Rrho1_0(file):
	"extracts R(rho1) at theta=0"
	file=open(file,'r')
	lines=file.readlines()
	line_x=lines[1]
	line_x=line_x.split()
	return line_x[1]

def extract_Rrho2_0(file):
	"extracts R(rho2) at theta=0"
	file=open(file,'r')
	lines=file.readlines()
	line_x=lines[1]
	line_x=line_x.split()
	return line_x[2]

print 'set obj rect from '+extract_Rrho1_0(file1)+' , graph 0 to '+extract_Rrho2_0(file1)+' , graph 1 fc rgb "red" '
print 'set obj rect from '+extract_Rrho1_0(file2)+' , graph 0 to '+extract_Rrho2_0(file2)+' , graph 1 fc rgb "blue" '
print 'set obj rect from '+extract_Rrho1_0(file3)+' , graph 0 to '+extract_Rrho2_0(file3)+' , graph 1 fc rgb "green" '





