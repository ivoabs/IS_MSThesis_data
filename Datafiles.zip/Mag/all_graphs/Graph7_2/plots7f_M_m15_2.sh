#!/usr/bin/gnuplot -persist
set terminal pdfcairo enhanced
#set terminal wxt size 350,262 enhanced font 'Verdana,10' persist

set output "Mpotf_FSU2R_m15.pdf"
#set output "Mpotf_FSU2R_m15.txt"


set autoscale
set xlabel "r [km]"
set ylabel "M(r)"


set style line 1 lt 1

set style rect fc lt -1 fs solid 1. noborder


set obj rect from 9.49020630025, graph 0 to 9.4773057915, graph 1 fc rgb "#e3f2fd" 
set obj rect from 9.58681649466, graph 0 to 9.57244014011, graph 1 fc rgb "#90caf9"
set obj rect from 9.67578287661, graph 0 to 9.66128398176, graph 1 fc rgb "#1976d2"
set obj rect from 9.71203573459, graph 0 to 9.69763662593, graph 1 fc rgb "#0d47a1"


set multiplot
# === Large plot ===
unset key
plot "Magpot_FSU2R_m15.d" using 1:2 with lines ls 1 lc rgb "#e3f2fd"  title "π/8" at end ,\
"Magpot_FSU2R_m15.d" using 1:3 with lines ls 1 lc rgb "#90caf9" title "π/4" at end,\
"Magpot_FSU2R_m15.d" using 1:4 with lines ls 1 lc rgb "#1976d2" title "3π/8" at end,\
"Magpot_FSU2R_m15.d" using 1:5 with lines ls 1 lc rgb "#0d47a1" title "π/2" at end,\

# === Small plot ===
set origin 8.,0.0
set size 3,3
set xrange [8:10]
set yrange [-0.0035:0]
unset xlabel
unset ylabel
unset label


plot "Magpot_FSU2R_m15.d" using 1:2 with lines ls 1 lc rgb "purple",\
"Magpot_FSU2R_m15.d" using 1:3 with lines ls 1 lc rgb "brown" ,\
"Magpot_FSU2R_m15.d" using 1:4 with lines ls 1 lc rgb "cyan" ,\
"Magpot_FSU2R_m15.d" using 1:5 with lines ls 1 lc rgb "grey" 

unset multiplot