#!/usr/bin/gnuplot -persist
set terminal pdfcairo enhanced
#set terminal wxt size 350,262 enhanced font 'Verdana,10' persist

set output "Mpotf_all_m12.pdf"
#set output "Mpotf_FSU2R_m15.txt"


set autoscale
set xlabel "r [km]"
set ylabel "M(r)"


set xrange [0:12]
 set key left bottom

set termoption dashed

set style line 1 lt 1


set style rect fc lt -1 fs transparent noborder

#L55
set obj rect from 10.1683209478 , graph 0 to 9.87274964114 , graph 1 fc rgb "#d50000"  fs transparent pattern 3
#L88
set obj rect from 10.8048404914 , graph 0 to 9.30535241915 , graph 1 fc rgb "#d50000" fs transparent pattern 7


plot "Magpot_L55_m12.d" using 1:5 with lines ls 1 lc rgb "#d50000" title "L=55",\
"Magpot_angles_L88_m12.d" using 1:5 with lines dt 2 lc rgb "#d50000" title "L=88"
#set obj rect from 10.1683209478 , graph 0 to 9.87274964114 , graph 1 fc rgb "green" fs transparent pattern 7
